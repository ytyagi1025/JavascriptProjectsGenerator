/*
* ExampleJs - Just an example project.
* Author: Ronen Ness, Fri Oct 23 01:27:47 2015
*/


// set namespace
var ExampleJs = ExampleJs || {};

// version identifier
// note: do not change this value in the source files, it is assigned by the build script
ExampleJs.VERSION = "___curr_version___";
