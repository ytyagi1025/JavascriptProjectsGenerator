/*
* This file is just to make this package npm compliant.
* Author: Ronen Ness, Fri Oct 23 01:27:47 2015
*/

if (typeof exports !== "undefined")
{
	exports.examplejs = ExampleJs;
}