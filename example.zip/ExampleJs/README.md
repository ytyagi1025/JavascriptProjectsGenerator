# ExampleJs - Just an example project

This is just an example project made with the projects generator.

## Table of Contents

- [What is it?](#what-is-it)
- [Key Features](#key-features)
- [How to use](#how-to-use)
- [Quick example](#quick-example)
- [How to build](#how-to-build)
- [Change log](#change-log)
- [License](#license)

## What is it?

An example project.

## Key Features
The following are the key features of ExampleJs:

- Can make coffee.
- Can turn all your dreams into reality.
- Will always lie about key features.
- Also really lightweight!

## How to use

Get the latest version of ExampleJs from dist/ folder in this git, and include it in your html head section, like this:

```html
<script src="ExampleJs.1.0.min.js"></script>
```

Or

```html
<script src="ExampleJs.1.0.js"></script>
```

For un-minified version.


### Quick example

Nope.

### ExampleJs Tutorial

Na-ah.

## How to build

To build a dev version, run the script **build.py**. 
Note: only the javascript files listed in *files_to_build.txt* will be compiled.

To make a new version, run the script **make_version.py**.
This will build a new distribution version based on the last dev build.

## Change log

### 1.0.0

Nothing changed.

### 1.0.1

Still nothing.
	
## License

ExampleJs is provided under the zlib-license, and is absolutely free for use for personal, educational and commercial purposes.
See LICENSE.txt for more info.

## Contact Me

For issues / bugs please use the Report Issue button.
For anything else, feel free to contact me: ronenness@gmail.com.


