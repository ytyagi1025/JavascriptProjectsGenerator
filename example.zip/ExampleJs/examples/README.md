The following examples are meant to run from your filesystem. 
Simply open any html file in any browser to test it on your local machine.
