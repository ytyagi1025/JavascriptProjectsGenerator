/*
* HelloWorld - This is an example project!.
* Author: Ronen Ness, <Data>
*/


// set namespace
var HelloWorld = HelloWorld || {};

// version identifier
// note: do not change this value in the source files, it is assigned by the build script
HelloWorld.VERSION = "___curr_version___";

// license
HelloWorld.LICENSE = __helloworld_license;
