/*
* This file is just to make this package npm compliant.
* Author: Ronen Ness, Tue Oct 20 00:44:52 2015
*/

if (typeof exports !== "undefined")
{
	exports.helloworld = HelloWorld;
}